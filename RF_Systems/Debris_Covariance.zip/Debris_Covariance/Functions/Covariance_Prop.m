function [final_state, final_cov, t_limit] = Covariance_Prop(X0, P0, tspan, error_limit)
    mu = 3.986e14;

    % Position (km) and velocity (km/s) uncertainties
    tf = tspan(2);
    t = tspan(1);


    initial_conditions_cov = [X0', reshape(P0,1,36)];
    
    
    
    P_flat = reshape(P0,[],1);
    
    options_ode45 = odeset('AbsTol',1e-6, 'RelTol',1e-9);

    %Covariance Prop + State Prop
    [Time_out,Cov_out] = ode45(@(t,x)cov_2BP_with_STM(t,x,mu),tspan,initial_conditions_cov,options_ode45);
    
    sigma_x = sqrt(Cov_out(:,7));
    sigma_y = sqrt(Cov_out(:,14));
    sigma_z = sqrt(Cov_out(:,21));
    
    %Find the revisit time
    for i = 1:length(sigma_x(:,1))      %Cycle through the error arrays to see when the revisit time limit is reached
        if (sigma_x(i,1) >= error_limit) || (sigma_y(i,1) >= error_limit)|| (sigma_z(i,1) >= error_limit)
            t_limit = Time_out(i,1);    %Store the time the error is larger than the Optical FOV radius
            t_limit_idx = i;
            final_cov_flat = Cov_out(i, 7:42);
            final_cov = reshape(final_cov_flat, 6, 6);
            disp('Final Covariance Matrix:');
            disp(final_cov);
            final_state_flat = Cov_out(i,1:6);
            final_state = reshape(final_state_flat,6,1);
            break
        end
    end
    
    
    
    Time_out_hrs = Time_out/3600; 
    figure;
    plot(Time_out_hrs, 3*sigma_x, 'r', 'LineWidth', 1.5); 
    hold on;
    plot(Time_out_hrs, 3*sigma_y, 'g', 'LineWidth', 1.5);
    plot(Time_out_hrs, 3*sigma_z, 'b', 'LineWidth', 1.5);
    xlabel('Time [hrs]');
    ylabel('Position Uncertainty (km)');
    legend('\sigma_x', '\sigma_y', '\sigma_z');
    title('Covariance Growth Over Time');
    grid on;
    xlim([0 50])
    
    % Plot Position vs. Time with ±3σ Uncertainty Envelopes    
    figure;
    
    % Plot x-coordinate
    subplot(3,1,1);
    plot(Time_out_hrs, Cov_out(:,1), 'b', 'LineWidth', 1.5);
    hold on;
    plot(Time_out_hrs, Cov_out(:,1) + 3*sigma_x, 'r--', 'LineWidth', 1.0);
    plot(Time_out_hrs, Cov_out(:,1) - 3*sigma_x, 'r--', 'LineWidth', 1.0);
    xline(t_limit/3600, 'r:', 'LineWidth',1)
    xlabel('Time (hrs)');
    ylabel('X Position (km)');
    title('X Position with ±3σ Uncertainty');
    grid on;
    ylim([-1e5 1e5])
    xlim([0 50])
    % Plot y-coordinate
    subplot(3,1,2);
    plot(Time_out_hrs, Cov_out(:,2), 'b', 'LineWidth', 1.5);
    hold on;
    plot(Time_out_hrs, Cov_out(:,2) + 3*sigma_y, 'r--', 'LineWidth', 1.0);
    plot(Time_out_hrs, Cov_out(:,2) - 3*sigma_y, 'r--', 'LineWidth', 1.0);
    xline(t_limit/3600, 'r:', 'LineWidth',1)
    xlabel('Time (hrs)');
    ylabel('Y Position (km)');
    title('Y Position with ±3σ Uncertainty');
    grid on;
    ylim([-1e5 1e5])
    xlim([0 50])
    % Plot z-coordinate
    subplot(3,1,3);
    plot(Time_out_hrs, Cov_out(:,3), 'b', 'LineWidth', 1.5);
    hold on;
    plot(Time_out_hrs, Cov_out(:,3) + 3*sigma_z, 'r--', 'LineWidth', 1.0);
    plot(Time_out_hrs, Cov_out(:,3) - 3*sigma_z, 'r--', 'LineWidth', 1.0);
    xline(t_limit/3600, 'r:', 'LineWidth',1)
    xlabel('Time (hrs)');
    ylabel('Z Position (km)');
    title('Z Position with ±3σ Uncertainty');
    grid on;
    
    ylim([-1e5 1e5])
    xlim([0 50])
end

%Verified with Monte-Carlo simulation, it has an error of ~1%